﻿using System;
using ProcessScheduling;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProjectScheduling
{
    [TestClass]
    public class ReadyQueueTests
    {
        [TestMethod]
        public void T10_RQ_EmptyQueue()
        {
            ReadyQueue queue = new ReadyQueue();
            Assert.IsNull(queue.DequeueFirst(), "Ein first in leerer Queue");
            Assert.IsNull(queue.DequeueLast(), "Ein last in leerer Queue");
        }

        [TestMethod]
        public void T11_RQ_Enqueue_OneProcess()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p = new Process(80);
            queue.Enqueue(p);
            Process first = queue.DequeueFirst();
            Assert.IsNotNull(first, "Es wurde kein first gefunden");
            Assert.AreEqual(p, first, "First entspricht nicht dem eingefügten Prozess");
            Process last = queue.DequeueLast();
            Assert.IsNull(last, "Jetzt darf kein last mehr in der Queue sein");
        }

        [TestMethod]
        public void T12_RQ_Enqueue_TwoProcesses_DifferentPriority()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(50);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Process first = queue.DequeueFirst();
            Assert.IsNotNull(first, "Es wurde kein first gefunden");
            Assert.AreEqual(p2, first, "First entspricht nicht dem Prozess mit der höchsten Priorität");
            Process last = queue.DequeueLast();
            Assert.IsNotNull(last, "Es muss noch einen letzten Prozess gegeben haben");
            Assert.AreEqual(p1, last, "Last muss der Prozess mit der zweithöchsten Priorität sein");
        }

        [TestMethod]
        public void T13_RQ_Enqueue_TwoProcesses_SamePriority()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(80);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Process first = queue.DequeueFirst();
            Assert.IsNotNull(first, "Es wurde kein first gefunden");
            Assert.AreEqual(p1, first, "First entspricht nicht dem Prozess, der als erstes eingefügt wurde.");
            Process last = queue.DequeueLast();
            Assert.IsNotNull(last, "Es muss noch einen letzten Prozess gegeben haben.");
            Assert.AreEqual(p2, last, "Last muss der Prozess, der als zweites eingefügt wurde, sein.");
        }

        [TestMethod]
        public void T14_RQ_Enqueue_MoreProcesses_MixedPriority()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(80);
            Process p3 = new Process(40);
            Process p4 = new Process(90);
            Process p5 = new Process(1);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            queue.Enqueue(p3);
            queue.Enqueue(p4);
            queue.Enqueue(p5);
            Process first = queue.DequeueFirst();
            Assert.IsNotNull(first, "Es wurde kein first gefunden");
            Assert.AreEqual(p5, first, "First entspricht nicht dem Prozess mit höchster Priorität");
            Process last = queue.DequeueLast();
            Assert.IsNotNull(last, "Es muss einen letzten Prozess gegeben haben.");
            Assert.AreEqual(p4, last, "Last müsste der Prozess 4 sein.");
        }


        [TestMethod]
        public void T15_RQ_Remove_FromEmptyQueue()
        {
            ReadyQueue queue = new ReadyQueue();
            Assert.IsFalse(queue.Dequeue(null), "Nichts kann nicht entfernt werden");
            Process p1 = new Process(80);
            Assert.IsFalse(queue.Dequeue(p1), "P1 kann nicht aus leerer Queue entfernt werden.");
        }

        [TestMethod]
        public void T16_RQ_Remove_FromFilledQueue()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(80);
            Process p3 = new Process(40);
            Process p4 = new Process(90);
            Process p5 = new Process(1);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            queue.Enqueue(p3);
            queue.Enqueue(p4);
            queue.Enqueue(p5);
            Assert.IsTrue(queue.Dequeue(p5), "P5 müsste entfernt werden können.");
            Assert.AreEqual(p3, queue.DequeueFirst(), "P3 müsste jetzt der wichtigste Prozess sein.");
        }

        [TestMethod]
        public void T17_RQ_Remove_LastFromFilledQueue()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(80);
            Process p3 = new Process(40);
            Process p4 = new Process(90);
            Process p5 = new Process(1);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            queue.Enqueue(p3);
            queue.Enqueue(p4);
            queue.Enqueue(p5);
            Assert.IsTrue(queue.Dequeue(p2), "P2 müsste entfernt werden können.");
            Assert.AreEqual(p4, queue.DequeueLast(), "P4 müsste neuer letzter Prozess sein.");
            Assert.IsFalse(queue.Dequeue(p4), "P4 darf jetzt nicht mehr entfernt werden können.");
            Assert.AreEqual(p2, queue.DequeueLast(), "P2 müsste neuer letzter Prozess sein.");
        }

        [TestMethod]
        public void T18_RQ_Remove_NotFound()
        {
            ReadyQueue queue = new ReadyQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(80);
            queue.Enqueue(p1);
            Assert.IsFalse(queue.Dequeue(p2), "P2 kann nicht entfernt werden.");
        }

    }
}
