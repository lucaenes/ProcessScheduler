﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProcessScheduling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessScheduling.Tests
{
    [TestClass()]
    public class SchedulerTests
    {
        [TestMethod()]
        public void T19_Scheduler_NoProcessTest()
        {
            Scheduler scheduler = new Scheduler();
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess, 
                "Ohne Prozesse muss zumindest der IdleProcess laufen.");
        }

        [TestMethod()]
        public void T20_Scheduler_OneProcessStarted()
        {
            Scheduler scheduler = new Scheduler();
            Process p1 = new Process(Process.MIN_PRIORITY);
            int pid1 = p1.PID;
            scheduler.StartProcess(p1);
            Assert.AreEqual(ProcessState.Ready, p1.State, 
                "Prozess ist nach Starten laufbereit.");
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(scheduler.RunningProcess, p1,
                "Jetzt muß der einzige Prozess aus der ReadyQueue laufen.");
            Assert.AreEqual(ProcessState.Running, p1.State, 
                "Prozess läuft jetzt.");
        }

        [TestMethod()]
        public void T21_Scheduler_MoreProcessesStarted_DifferentPriorities()
        {
            Scheduler scheduler = new Scheduler();
            Process p1 = new Process(Process.MIN_PRIORITY);
            scheduler.StartProcess(p1);
            Process p2 = new Process(Process.MIN_PRIORITY + 1);
            scheduler.StartProcess(p2);
            Assert.AreEqual(ProcessState.Ready, p1.State, 
                "Prozess 1 ist nach Starten laufbereit.");
            Assert.AreEqual(ProcessState.Ready, p2.State, 
                "Prozess 2 ist nach Starten laufbereit.");
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(p1, scheduler.RunningProcess,
                "Jetzt muß der vorderste Prozess aus der ReadyQueue laufen.");
            Assert.AreEqual(ProcessState.Running, p1.State, 
                "Prozess läuft jetzt.");
            Assert.AreEqual(ProcessState.Ready, p2.State, 
                "Prozess 2 ist noch immer laufbereit.");

        }

        [TestMethod()]
        public void T22_Scheduler_MoreProcessesStarted_SamePriority()
        {
            Scheduler scheduler = new Scheduler();
            Process p1 = new Process(Process.MIN_PRIORITY);
            scheduler.StartProcess(p1);
            Process p2 = new Process(Process.MIN_PRIORITY);
            scheduler.StartProcess(p2);
            Assert.AreEqual(ProcessState.Ready, p1.State, 
                "Prozess 1 ist nach Starten laufbereit.");
            Assert.AreEqual(ProcessState.Ready, p2.State, 
                "Prozess 2 ist nach Starten laufbereit.");
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(p1, scheduler.RunningProcess, 
                "Jetzt muß der vorderste Prozess aus der ReadyQueue laufen.");
            Assert.AreEqual(ProcessState.Running, p1.State, 
                "Prozess läuft jetzt.");
            Assert.AreEqual(ProcessState.Ready, p2.State, 
                "Prozess 2 ist noch immer laufbereit.");

        }

        [TestMethod()]
        public void T23_Scheduler_MoreProcessesStarted_ReversedPriorities()
        {
            Scheduler scheduler = new Scheduler();
            Process p1 = new Process(Process.MIN_PRIORITY + 1);
            scheduler.StartProcess(p1);
            Process p2 = new Process(Process.MIN_PRIORITY);
            scheduler.StartProcess(p2);
            Assert.AreEqual(ProcessState.Ready, p1.State, 
                "Prozess 1 ist nach Starten laufbereit.");
            Assert.AreEqual(ProcessState.Ready, p2.State,  
                "Prozess 2 ist nach Starten laufbereit.");
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(p2, scheduler.RunningProcess,
                "Jetzt muß der vorderste Prozess aus der ReadyQueue laufen.");
            Assert.AreEqual(ProcessState.Running, p2.State, 
                "Prozess läuft jetzt.");
            Assert.AreEqual(ProcessState.Ready, p1.State, 
                "Prozess 1 wäre der nächste Prozess.");
        }

        [TestMethod()]
        public void T24_Scheduler_MoreThanTwoProcessesStarted_DifferentPriorities()
        {
            Scheduler scheduler = new Scheduler();
            Process[] processes = new Process[5];

            processes[0] = new Process(50);
            processes[1] = new Process(70);
            processes[2] = new Process(20);
            processes[3] = new Process(1);
            processes[4] = new Process(180);

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.StartProcess(processes[i]);
            }

            scheduler.ScheduleNextProcess();
            Assert.AreEqual(1, scheduler.RunningProcess.Priority,
                "Der Prozess mit Prio 1 müsste jetzt laufen.");
            Assert.AreEqual(ProcessState.Running, processes[3].State, 
                "Prozess 4 müsste jetzt Status Running haben.");
        }

        [TestMethod()]
        public void T25_Scheduler_StartAndRunProcesses()
        {
            Scheduler scheduler = new Scheduler();
            Process[] processes = new Process[5];

            processes[0] = new Process(50);
            processes[1] = new Process(50);
            processes[2] = new Process(20);
            processes[3] = new Process(1);
            processes[4] = new Process(180);

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.StartProcess(processes[i]);
            }

            scheduler.ScheduleNextProcess();
            Assert.AreEqual(processes[3], scheduler.RunningProcess,
                "Prozess 4 müsste jetzt laufen.");
       
            Assert.AreEqual(ProcessState.Running, processes[3].State, 
                "Prozess 4 müsste noch immer laufen.");
            Assert.AreEqual(processes[3], scheduler.RunningProcess,
                "Prozess 4 müsste wieder der nächste Prozess gewesen sein sein.");

        }

        [TestMethod()]
        public void T26_Scheduler_StartProcess_AlreadyStarted()
        {
            Scheduler scheduler = new Scheduler();
            Process[] processes = new Process[5];

            processes[0] = new Process(50);
            processes[1] = new Process(70);
            processes[2] = new Process(20);
            processes[3] = new Process(1);
            processes[4] = new Process(180);

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.StartProcess(processes[i]);
            }
            scheduler.StartProcess(processes[3]);
            scheduler.StartProcess(processes[0]);

            scheduler.ScheduleNextProcess();
                   Assert.AreEqual(ProcessState.Running, processes[3].State, 
                "Prozess 4 müsste jetzt Status Running haben.");
        }

        [TestMethod()]
        public void T27_Scheduler_SuspendAndResumeProcess_OneProcessOnly()
        {
            Scheduler scheduler = new Scheduler();
            Process p = new Process(50);
            int pid = p.PID;
            scheduler.StartProcess(p);
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(p, scheduler.RunningProcess, 
                "Prozess p müsste laufen");

            scheduler.SuspendProcess(p);
            Assert.AreEqual(ProcessState.Waiting, p.State, 
                "Prozess müsste jetzt in der WaitingQueue sein.");
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess, 
                "IdleProcess müsste laufen");

            scheduler.ResumeProcess(pid);
            Assert.AreEqual(ProcessState.Ready, p.State,
                "Prozess müsste jetzt wieder in der ReadyQueue sein.");
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(ProcessState.Running, p.State,
                "Prozess müsste jetzt laufen.");
            Assert.AreEqual(p, scheduler.RunningProcess,
                "Prozess müsste jetzt laufen.");        
        }

        [TestMethod()]
         public void T28_Scheduler_SuspendAndResumeProcess_MoreProcesses()
        {
            Scheduler scheduler = new Scheduler();
            Process[] processes = new Process[5];

            processes[0] = new Process(50);
            processes[1] = new Process(50);
            processes[2] = new Process(20);
            processes[3] = new Process(1);
            processes[4] = new Process(180);

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.StartProcess(processes[i]);
            }

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.SuspendProcess(processes[i]);
            }

            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "Alle Prozesse müssten jetzt Waiting sein");

            for (int i = 0; i < processes.Length; i++)
            {
                Assert.AreEqual(ProcessState.Waiting, processes[i].State,
                    "Alle Prozesse müssten jetzt Waiting sein.");
            }

            for (int i = 0; i < 3; i++)
            {
                scheduler.ResumeProcess(processes[i].PID);
                Assert.AreEqual(ProcessState.Ready, processes[i].State,
                    "Nach Resume muss Status Ready sein.");
            }

            scheduler.ScheduleNextProcess();
            Assert.AreEqual(processes[2], scheduler.RunningProcess,
                "Prozess 3 müsste jetzt laufen.");

            scheduler.SuspendProcess(processes[2]);
            Assert.AreEqual(processes[0], scheduler.RunningProcess,
                "Prozess 1 müsste jetzt der vorderste Ready-Prozess sein und laufen.");

            scheduler.ScheduleNextProcess();
            Assert.AreEqual(processes[1], scheduler.RunningProcess,
                "Prozess 2 müsste jetzt laufen, weil er länger wartet als Prozess 1.");

            scheduler.ScheduleNextProcess();
            Assert.AreEqual(processes[0], scheduler.RunningProcess,
                "Jetzt ist wieder Prozess 1 dran, Prozess 2 wurde hinten eingereiht.");
        }

        [TestMethod()]
        public void T29_Scheduler_SuspendProcess_InvalidState()
        {
            Scheduler scheduler = new Scheduler();
            Process[] processes = new Process[5];

            processes[0] = new Process(50);
            processes[1] = new Process(50);
            processes[2] = new Process(20);
            processes[3] = new Process(1);
            processes[4] = new Process(180);

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.StartProcess(processes[i]);
            }

            scheduler.SuspendProcess(processes[2]);
            Assert.AreEqual(ProcessState.Waiting, processes[2].State,
                "Ready Process wurde suspendiert und ist jetzt Waiting.");

            scheduler.SuspendProcess(processes[2]);
            Assert.AreEqual(ProcessState.Waiting, processes[2].State,
                "Ready Process wurde nochmal suspendiert und ist noch immer Waiting");

        }

        [TestMethod()]
        public void T30_Scheduler_Kill_RunningProcess()
        {
            Scheduler scheduler = new Scheduler();

            Process p = new Process(50);
            int pid = p.PID;
            scheduler.StartProcess(p);
            scheduler.ScheduleNextProcess();
            scheduler.KillProcess(p);

            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "Jetzt ist die CPU idle");
            Assert.AreEqual(ProcessState.Terminated, p.State,
                "Prozess sollte Terminated sein.");
        }

        [TestMethod()]
        public void T31_Scheduler_Kill_WaitingProcess()
        {
            Scheduler scheduler = new Scheduler();

            Process p = new Process(50);
            int pid = p.PID;
            scheduler.StartProcess(p);
            scheduler.ScheduleNextProcess();
            scheduler.SuspendProcess(p);

            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "Jetzt ist die CPU idle");
            Assert.AreEqual(ProcessState.Waiting, p.State,
                "Prozess sollte Terminated sein.");

            scheduler.KillProcess(p);
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "Jetzt ist die CPU idle");
            Assert.AreEqual(ProcessState.Terminated, p.State,
                "Prozess sollte Terminated sein.");

            scheduler.ResumeProcess(pid);
            Assert.AreEqual(ProcessState.Terminated, p.State,
                "Prozess kann nicht mehr resumed werden, bleibt Terminated.");
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "Jetzt ist die CPU idle");
            scheduler.StartProcess(new Process(80));
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(80, scheduler.RunningProcess.Priority,
                "Jetzt ist der Prozess mit Prio 80 laufend, 50-er Prozess bleibt Terminated.");

            scheduler.SuspendProcess(p);

            Assert.AreEqual(ProcessState.Terminated, p.State,
                "Terminated Prozess kann nicht suspendiert werden.");
        }

        [TestMethod()]
        public void T32_Scheduler_Kill_ReadyProcess()
        {
            Scheduler scheduler = new Scheduler();

            scheduler.StartProcess(new Process(80));
            scheduler.ScheduleNextProcess();
            Process p = new Process(50);
            int pid = p.PID;
            scheduler.StartProcess(p);

            Assert.AreEqual(ProcessState.Ready, p.State,
                "Prozess sollte Ready sein.");

            scheduler.KillProcess(p);

            Assert.AreEqual(80, scheduler.RunningProcess.Priority,
                "Jetzt läuft noch immer der 80er-Prozess.");
            Assert.AreEqual(ProcessState.Terminated, p.State,
                "Prozess sollte Terminated sein.");
        }

        [TestMethod()]
        public void T33_Scheduler_AgeLastProcess()
        {
            Scheduler scheduler = new Scheduler();
            Process[] processes = new Process[5];

            processes[0] = new Process(50);
            processes[1] = new Process(50);
            processes[2] = new Process(80);
            processes[3] = new Process(20);
            processes[4] = new Process(180);

            for (int i = 0; i < processes.Length; i++)
            {
                scheduler.StartProcess(processes[i]);
            }

            scheduler.ScheduleNextProcess();
            Assert.AreEqual(processes[3], scheduler.RunningProcess,
                "Prozess 4 hat die Top-Prio und läuft.");

            scheduler.AgeLastProcess(130);
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(processes[4], scheduler.RunningProcess,
                "Priorität von Prozess 5 sollte nun von 149 auf 19 erhöht worden sein und als nächster laufen.");
        }

        [TestMethod()]
        public void T34_Scheduler_IdleProcess_NoSuspendNoKillNoAge()
        {
            Scheduler scheduler = new Scheduler();
            scheduler.ScheduleNextProcess();
            Assert.AreEqual(ProcessState.Running, Process.IdleProcess.State,
                "IdleProcess läuft.");
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "IdleProcess läuft.");

            scheduler.SuspendProcess(Process.IdleProcess);
            Assert.AreEqual(ProcessState.Running, Process.IdleProcess.State,
                "IdleProcess läuft trotz Suspend.");
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "IdleProcess läuft trotz Suspend.");

            scheduler.KillProcess(Process.IdleProcess);
            Assert.AreEqual(ProcessState.Running, Process.IdleProcess.State,
                "IdleProcess läuft trotz Kill.");
            Assert.AreEqual(Process.IdleProcess, scheduler.RunningProcess,
                "IdleProcess läuft trotz Kill.");

            scheduler.AgeLastProcess(50);
            Assert.AreEqual(150, Process.IdleProcess.Priority,
                "Aging für IdleProcess nicht möglich, Priorität bleibt gleich.");
        }
    }
}