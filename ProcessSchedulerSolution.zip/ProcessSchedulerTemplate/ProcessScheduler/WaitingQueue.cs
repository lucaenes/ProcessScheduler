﻿using System;


namespace ProcessScheduling
{
    /// <summary>
    /// LinkedList zur Verwaltung aller suspendierten
    /// Prozesse.
    /// </summary>
    public class WaitingQueue
    {

       public Node head = null;

        /// <summary>
        /// Ein neuer Prozess wird unsortiert eingefügt,
        /// es sei denn, er ist bereits in der Liste enthalten.
        /// </summary>
        /// <param name="p">Einzukettender Prozess</param>
        /// <returns>True, wenn er eingefügt wurde,
        /// False, wenn er bereits in der Liste enthalten ist.
        /// </returns>
        public bool Enqueue(Process p)
        {
            Node insert = new Node(p);
            bool inserted = false;

            if (head == null)
            {
                head = insert;
                insert.Data.State = ProcessState.Waiting;
                return inserted = true;
                
            }

            Node temp = head;
            while (temp.Next != null)
            {
                if (temp.Next.Data == insert.Data)
                {
                    return inserted = false;
                }
                temp = temp.Next;
            }
            insert.Next = temp.Next;
            temp.Next = insert;
            insert.Data.State = ProcessState.Waiting;
            return inserted = true;

        }

        /// <summary>
        /// Der Prozess mit der gesuchten PID wird
        /// ausgekettet und zurückgeliefert.
        /// </summary>
        /// <param name="pid">Gesuchte PID</param>
        /// <returns>Ausgeketteter Prozess oder null,
        /// wenn es keinen Prozess mit der gesuchten 
        /// PID in der Liste gibt.
        /// </returns>
        public Process Dequeue(int pid)
        {

            if (head == null)
            {
                return null;
            }
            else if (head.Data.PID == pid)
            {
               Process first = head.Data;
               head = head.Next;
               return first;
            }

            Node temp = head;
            while (temp.Next != null)
            {
                if (temp.Data.PID == pid)
                {
                    return temp.Data;
                }
                temp = temp.Next;
            }
            if (temp.Data.PID == pid)
            {
                return temp.Data;
            }
            return null;
            

        }

        /// <summary>
        /// Überprüft, ob der gesuchte Prozess in der
        /// Liste enthalten ist.
        /// </summary>
        /// <param name="p">Gesuchter Prozess</param>
        /// <returns>True wenn vorhanden, sonst false.</returns>
        public bool Contains(Process p)
        {
            if (head == null)
            {
                return false;
            }
            if (head.Data == p)
            {
                p.State = ProcessState.Waiting;
                return true;
            }

            Node temp = head;
            while (temp.Next != null)
            {
                if (temp.Data == p)
                {
                    p.State = ProcessState.Waiting;
                    return true;
                }
                temp = temp.Next;
            }
            if (temp.Data == p)
            {
                p.State = ProcessState.Waiting;
                return true;
            }
            return false;
        }
    }
}
