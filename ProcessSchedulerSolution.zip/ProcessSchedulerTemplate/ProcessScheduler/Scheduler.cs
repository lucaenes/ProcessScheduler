﻿/* Sehr geehrter Herr Auernig,
 * 
 * Ich durfte mit Juni eine Lehrer bei der Firma x-tention als
 * IT-Techniker/Informatiker anfangen.
 * Ich bin so froh, dass sich mein Leben in diese Richtung entwickelte,
 * da mich meine Kollegen wie auch mein Arbeitsalltag so motivieren mich 
 * in diesem Bereich zu etabalieren und eine gute Karriere zu starten maßlos steigerte. 
 * Mittlerweile hab ich riesen gefallen am Programmieren gefunden und verstanden, dass es 
 * eine Fertigkeit ist die man nur erlernt wenn man es auch wirklich will und fast täglich übt.
 * ich wollte mich für die Basics danken, da ich ohneSie wahrscheinlich keine Chance gehabt hätte.
 * Hier eines ihrer Programme, das ich in 2 Tagen implementierte. 
 * Vielleicht begegnen wir uns nochmal auf unseren Wegen.
 * 
 * Liebe Grüße Luca Fürstberger
 */

using System;

namespace ProcessScheduling
{

    /// <summary>
    /// Klasse zum Verwaltung des aktuell laufenden Prozesses.
    /// Alle anderen Prozesse befinden sich entweder in der 
    /// ReadyQueue oder in der WaitingQueue.
    /// </summary>
    public class Scheduler
    {
        Node head = new Node(null);
        ReadyQueue readyQueue = new ReadyQueue();
        WaitingQueue waitingQueue = new WaitingQueue();

        /// <summary>
        /// Nur der Scheduler selbst darf den aktuell
        /// laufenden Prozess setzen.
        /// Das Auslesen des aktuell laufenden Prozesses
        /// hingegen ist öffentlich.
        /// </summary>
        public Process RunningProcess
        {
            get
            {
                if (head.Data == null)
                {
                    head.Data = Process.IdleProcess;
                    return head.Data;
                }
                else
                {
                    head.Data.State = ProcessState.Running;
                    return head.Data;
                }

            }
            private set
            {
                if (head == null)
                {
                    head.Data = Process.IdleProcess;
                    head.Data.State = ProcessState.Running;
                    head.Data = value;
                }
                else
                {
                    head.Data.State = ProcessState.Running;
                    head.Data = value;
                }
               
            }
        }

        /// <summary>
        /// Ein Prozesswechsel wird durchgeführt: Der
        /// aktuell laufende Prozess wird auf Ready
        /// zurückgesetzt (in die ReadyQueue eingereiht)
        /// und der vorderste Prozess aus der ReadyQueue
        /// wird zum RunningProcess. Gibt es keinen Ready-Prozess,
        /// kommt der IdleProcess zum Zug.
        /// </summary>
        public void ScheduleNextProcess()
        {
            Process next = readyQueue.DequeueFirst();
            Process actual = RunningProcess;

            if (next == null)
            {
                readyQueue.Enqueue(RunningProcess);
                RunningProcess = Process.IdleProcess;
                return;
            }
            
            else if(next != null)
            {
                if (RunningProcess == Process.IdleProcess)
                {
                    head.Data = next;
                    RunningProcess = next;
                    return;
                }
                readyQueue.Enqueue(RunningProcess);
                head.Data = next;
                RunningProcess = next;
                return;
            }
            


        }

        /// <summary>
        /// Es kann nur ein laufender oder laufbereiter Prozess
        /// suspendiert werden, auch nicht der IdleProcess.
        /// </summary>
        /// <param name="p"></param>
        public void SuspendProcess(Process p)
        {
            if (p.State == ProcessState.Running && p != Process.IdleProcess)
            {
                ScheduleNextProcess();
                p.State = ProcessState.Waiting;
                readyQueue.Dequeue(p);
                waitingQueue.Enqueue(p);
            }
            else if ( p.State == ProcessState.Ready && p != Process.IdleProcess)
            {
                p.State = ProcessState.Waiting;
                readyQueue.Dequeue(p);
                waitingQueue.Enqueue(p);
            }
           
        }


        /// <summary>
        /// Wenn der Prozess aus der WaitingQueue
        /// ausgekettet werden konnte, wird er in der
        /// ReadyQueue eingereiht.
        /// </summary>
        /// <param name="pid">Gesuchter Prozess muss diese PID haben.</param>
        public void ResumeProcess(int pid)
        {

            Node temp = waitingQueue.head;


            if (temp == null || pid < 0)
            {
                return;
            }

            if (head.Data.PID == pid)
            {
                if (temp.Data.State != ProcessState.Terminated)
                {
                    waitingQueue.Dequeue(head.Data.PID);
                    readyQueue.Enqueue(head.Data);
                    return;
                }
            }

            while (temp.Next != null)
            {
                if (temp.Data.PID == pid)
                {
                    if (temp.Data.State != ProcessState.Terminated)
                    {
                        waitingQueue.Dequeue(temp.Data.PID);
                        readyQueue.Enqueue(temp.Data);
                        return;
                    }
                }
                temp = temp.Next;
            }

            if (temp.Data.PID == pid)
            {
                if (temp.Data.State != ProcessState.Terminated)
                {
                    waitingQueue.Dequeue(temp.Data.PID);
                    readyQueue.Enqueue(temp.Data);
                    return;
                }
            }
        }

        /// <summary>
        /// Ein Prozess kann aus jedem beliebigen Zustand heraus
        /// gekillt werden, es sei denn, es handelt sich um den
        /// IdleProcess.
        /// Wurde der laufende Prozess gekillt, muss sofort ein
        /// neuer Prozess auf die CPU zugewiesen werden.
        /// </summary>
        /// <param name="p">Zu killender Prozess</param>
        public void KillProcess(Process p)
        {
            if (p != Process.IdleProcess)
            {
                if (p.State == ProcessState.Waiting)
                {
                    waitingQueue.Dequeue(p.PID);

                }
                else if (p.State == ProcessState.Ready)
                {
                    readyQueue.Dequeue(p);
                }

                if (RunningProcess == p)
                {
                    ScheduleNextProcess();
                }

                p.State = ProcessState.Terminated;
            }

        }

        /// <summary>
        /// Ein neuer Prozess wird dem Scheduler
        /// bekannt gemacht und sofort in die
        /// ReadyQueue eingereiht.
        /// </summary>
        /// <param name="p"></param>
        public void StartProcess(Process p)
        {
            readyQueue.Enqueue(p);
        }

        /// <summary>
        /// Um das Verhungern des letztes Prozesses
        /// in der ReadyQueue zu verhindern, kann dessen
        /// Priorität um einen zu definierenden Wert
        /// verbessert werden.
        /// </summary>
        /// <param name="increment">
        /// Um welchen Wert soll die Priorität besser werden.</param>
        public void AgeLastProcess(int increment)
        {
            Process last = readyQueue.DequeueLast();
            last.Priority = last.Priority - increment;
            readyQueue.Enqueue(last);

        }

    }
}
