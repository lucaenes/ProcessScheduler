﻿using System;

namespace ProcessScheduling
{
    /// <summary>
    /// LinkedList für die Verwaltung aller rechenbereiten
    /// Prozesse im System, sortiert nach Prioritäten.
    /// </summary>
    public class ReadyQueue
    {
        public Node head = null;

        /// <summary>
        /// Der übergebene Prozess wird nach Priorität
        /// sortiert eingefügt. Bei gleicher Priorität
        /// wird der einzufügende Prozess hinter dem bereits
        /// vorhandenen Prozess einsortiert.
        /// Ein niedriger Prioritätswert stellt eine hohe
        /// Priorität dar.
        /// Prozesszustand nach Einfügen ist Ready.
        /// </summary>
        /// <param name="p">Einzureihender Prozess</param>
        public void Enqueue(Process p)
        {
            Node insert = new Node(p);

            if (head == null)
            {
                head = insert;
                insert.Data.State = ProcessState.Ready;
                return;
            }

            else if (head.Data.Priority > insert.Data.Priority)
            {
                insert.Next = head;
                head = insert;
                insert.Data.State = ProcessState.Ready;
                return;
            }

            Node temp = head;
            Node prev = temp;
            while (temp.Next != null && temp.Next.Data.Priority < insert.Data.Priority)
            {
                prev = temp;
                temp = temp.Next;
            }

            if (temp.Data.Priority == insert.Data.Priority)
            {
                if (temp.Data.PID < insert.Data.PID)
                {
                    insert.Next = prev.Next;
                    prev.Next = insert;
                    insert.Data.State = ProcessState.Ready;
                    return;
                }
            }
            insert.Next = temp.Next;
            temp.Next = insert;
            insert.Data.State = ProcessState.Ready;
            return;


        }

        /// <summary>
        /// Der Prozess mit der höchsten Priorität
        /// bzw. bei gleich hoher Priorität der ältere
        /// wird ausgekettet und zurückgegeben.
        /// </summary>
        /// <returns>Der vorderste Prozess der Kette oder null,
        /// wenn die Kette leer ist.</returns>
        public Process DequeueFirst()
        {
            if (head == null)
            {
                return null;
            }

            Node temp = head;
            head = head.Next;
            return temp.Data;

        }
        /// <summary>
        /// Der Prozess mit der schlechtesten Priorität
        /// vom Ende der Kette wird ausgekettet und 
        /// zurückgegeben.
        /// </summary>
        /// <returns>Prozess am Ende der Kette oder null, wenn
        /// die Kette leer ist.</returns>
        public Process DequeueLast()
        {

            if (head == null)
            {
                return null;
            }

            Node temp = head;
            Node prev = temp;
            while (temp.Next != null)
            {
                prev = temp;
                temp = temp.Next;
            }
             prev.Next = temp.Next;
            return temp.Data;

        }

        /// <summary>
        /// Der übergebene Prozess wird in der Kette
        /// gesucht und wenn gefunden, ausgekettet.
        /// </summary>
        /// <param name="p">Auszukettender Prozess</param>
        /// <returns>True, wenn der Prozess ausgekettet wurde, 
        /// false, wenn er nicht in der Kette gefunden wurde.</returns>
        public bool Dequeue(Process p)
        {
            Node insert = new Node(p);
            bool embedded = false;

            if (head == null)
            {
                return embedded = false;
            }

            else if (head.Data == insert.Data)
            {
                    head = head.Next;
                    return embedded = true;
            }

            Node current = head;
            Node prev = head;
            while (current.Next != null && current.Next.Data != insert.Data)
            {
                prev = current;
                current = current.Next;
            }
            if (current.Next == null)
            {
                if (current.Data == insert.Data)
                {
                    return embedded = false;
                }
                
                return embedded = false;
            }
            
            prev.Next = current.Next;
            return embedded = true;

        }
    }
}

       