﻿
namespace ProcessScheduling
{
    public class Node
    {
        private Node _next;
        private Process _data;

        public Node Next
        {
            get { return _next; }
            set { _next = value; }
        }

        public Process Data
        {
            get { return _data; }
            set { _data = value; }
        }

        public Node(Node next, Process data)
        {
            Next = next;
            Data = data;
        }

        public Node(Process data):this(null, data) { }
    }
}
