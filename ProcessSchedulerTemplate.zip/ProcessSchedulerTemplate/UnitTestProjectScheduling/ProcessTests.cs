﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProcessScheduling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessScheduling.Tests
{
    [TestClass()]
    public class ProcessTests
    {
        [TestMethod()]
        public void T01_Process_IdleProcess()
        {
            Process idle = Process.IdleProcess;
            Assert.AreEqual(0, idle.PID, "Der Idle-Prozess hat immer ID 0");
            Assert.AreEqual(150, idle.Priority, "Der Idle-Prozess hat die niedrigste Priorität.");
        }

        [TestMethod()]
        public void T02_Process_PID_ConsecutiveAssignment()
        {
            Process p1 = new Process(25);
            int pid1 = p1.PID;
            Process p2 = new Process(10);
            Assert.AreEqual(pid1 + 1, p2.PID, "Der nächste Prozess bekommt die fortlaufend nächste ID.");
        }

        [TestMethod()]
        public void T03_Process_Priority_MinAndMax()
        {
            Process p1 = new Process(25);
            Assert.AreEqual(25, p1.Priority);

            p1.Priority = 250;
            Assert.AreEqual(Process.MAX_PRIORITY, p1.Priority, 
                "Priorität darf für normale Prozesse maximal " + Process.MAX_PRIORITY + " sein.");

            Process p2 = new Process(150);
            Assert.AreEqual(149, p2.Priority,
                "Priorität darf  für normale Prozesse maximal " + Process.MAX_PRIORITY + " sein.");

            p2.Priority = -30;
            Assert.AreEqual(0, p2.Priority, 
                "Priorität muß mindestens " + Process.MIN_PRIORITY + " sein.");
        }
    }
}
