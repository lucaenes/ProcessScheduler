﻿using System;
using ProcessScheduling;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProjectScheduling
{
    [TestClass]
    public class WaitingQueueTests
    {
        [TestMethod]
        public void T04_WQ_EmptyQueue()
        {
            WaitingQueue queue = new WaitingQueue();
            Assert.IsNull(queue.Dequeue(5), "Es gibt nichts zu entfernen");
            Assert.IsFalse(queue.Contains(new Process(150)), "Die Queue enthält nichts");
        }

        [TestMethod]
        public void T05_WQ_Enqueue_OneProcess()
        {
            WaitingQueue queue = new WaitingQueue();
            Process p = new Process(80);
            Assert.AreEqual(ProcessState.New, p.State, "Initialstatus ist nicht New.");
            p.State = ProcessState.Ready;
            queue.Enqueue(p);
            Assert.IsTrue(queue.Contains(p), "Waiting Queue kann den eingefügten Prozess nicht finden.");
            Assert.AreEqual(ProcessState.Waiting, p.State, "Status ist nicht Waiting.");
        }

        [TestMethod]
        public void T06_WQ_Enqueue_TwoProcesses()
        {
            WaitingQueue queue = new WaitingQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(50);
            p1.State = ProcessState.Ready;
            p2.State = ProcessState.Ready;
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Assert.IsTrue(queue.Contains(p1), "Es gibt p1 nicht in der Queue");
            Assert.IsTrue(queue.Contains(p2), "Es gibt p2 nicht in der Queue");
            Assert.AreEqual(ProcessState.Waiting, p1.State, "Status ist nicht Waiting.");
            Assert.AreEqual(ProcessState.Waiting, p2.State, "Status ist nicht Waiting.");
        }

        [TestMethod]
        public void T07_WQ_Enqueue_TwoProcesses()
        {
            WaitingQueue queue = new WaitingQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(50);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Assert.IsTrue(queue.Contains(p1), "Es gibt p1 nicht in der Queue");
            Assert.IsTrue(queue.Contains(p2), "Es gibt p2 nicht in der Queue");
            Assert.AreEqual(ProcessState.Waiting, p1.State, "Status ist nicht Waiting.");
            Assert.AreEqual(ProcessState.Waiting, p2.State, "Status ist nicht Waiting.");
        }

        [TestMethod]
        public void T08_WQ_Enqueue_Twice()
        {
            WaitingQueue queue = new WaitingQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(50);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Assert.IsFalse(queue.Enqueue(p2), "P2 kann nur einmal eingereiht werden.");
        }

        [TestMethod]
        public void T09_WQ_Dequeue_SomeProcesses()
        {
            WaitingQueue queue = new WaitingQueue();
            Process p1 = new Process(80);
            Process p2 = new Process(50);
            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Assert.AreEqual(p1, queue.Dequeue(p1.PID), "P1 konnte ausgereiht werden.");
            Assert.AreEqual(p2, queue.Dequeue(p2.PID), "P2 konnte ausgereiht werden.");
            Assert.IsNull(queue.Dequeue(97218), "PID unbekannt, kann nicht ausgereiht werden.");
            Assert.IsNull(queue.Dequeue(p1.PID), "P1 kann kein zweites Mal ausgereiht werden.");

            queue.Enqueue(p1);
            queue.Enqueue(p2);
            Assert.IsNull(queue.Dequeue(97218), "PID unbekannt, kann nicht ausgereiht werden.");

        }
    }
}
