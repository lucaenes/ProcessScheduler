﻿using System;

namespace ProcessScheduling
{
    /// <summary>
    /// LinkedList zur Verwaltung aller suspendierten
    /// Prozesse.
    /// </summary>
    public class WaitingQueue
    {


        /// <summary>
        /// Ein neuer Prozess wird unsortiert eingefügt,
        /// es sei denn, er ist bereits in der Liste enthalten.
        /// </summary>
        /// <param name="p">Einzukettender Prozess</param>
        /// <returns>True, wenn er eingefügt wurde,
        /// False, wenn er bereits in der Liste enthalten ist.
        /// </returns>
        public bool Enqueue(Process p)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Der Prozess mit der gesuchten PID wird
        /// ausgekettet und zurückgeliefert.
        /// </summary>
        /// <param name="pid">Gesuchte PID</param>
        /// <returns>Ausgeketteter Prozess oder null,
        /// wenn es keinen Prozess mit der gesuchten 
        /// PID in der Liste gibt.
        /// </returns>
        public Process Dequeue(int pid)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Überprüft, ob der gesuchte Prozess in der
        /// Liste enthalten ist.
        /// </summary>
        /// <param name="p">Gesuchter Prozess</param>
        /// <returns>True wenn vorhanden, sonst false.</returns>
        public bool Contains(Process p)
        {
            throw new NotImplementedException();
        }
    }
}
