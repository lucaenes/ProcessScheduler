﻿using System;

namespace ProcessScheduling
{
    /// <summary>
    /// LinkedList für die Verwaltung aller rechenbereiten
    /// Prozesse im System, sortiert nach Prioritäten.
    /// </summary>
    public class ReadyQueue
    {

        /// <summary>
        /// Der übergebene Prozess wird nach Priorität
        /// sortiert eingefügt. Bei gleicher Priorität
        /// wird der einzufügende Prozess hinter dem bereits
        /// vorhandenen Prozess einsortiert.
        /// Ein niedriger Prioritätswert stellt eine hohe
        /// Priorität dar.
        /// Prozesszustand nach Einfügen ist Ready.
        /// </summary>
        /// <param name="p">Einzureihender Prozess</param>
        public void Enqueue(Process p)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Der Prozess mit der höchsten Priorität
        /// bzw. bei gleich hoher Priorität der ältere
        /// wird ausgekettet und zurückgegeben.
        /// </summary>
        /// <returns>Der vorderste Prozess der Kette oder null,
        /// wenn die Kette leer ist.</returns>
        public Process DequeueFirst()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Der Prozess mit der schlechtesten Priorität
        /// vom Ende der Kette wird ausgekettet und 
        /// zurückgegeben.
        /// </summary>
        /// <returns>Prozess am Ende der Kette oder null, wenn
        /// die Kette leer ist.</returns>
        public Process DequeueLast()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Der übergebene Prozess wird in der Kette
        /// gesucht und wenn gefunden, ausgekettet.
        /// </summary>
        /// <param name="p">Auszukettender Prozess</param>
        /// <returns>True, wenn der Prozess ausgekettet wurde, 
        /// false, wenn er nicht in der Kette gefunden wurde.</returns>
        public bool Dequeue(Process p)
        {
            throw new NotImplementedException();
        }
    }
}
