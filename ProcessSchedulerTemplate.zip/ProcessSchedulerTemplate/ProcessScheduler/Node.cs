﻿
namespace ProcessScheduling
{
    public class Node
    {

    }
}
