﻿using System;

namespace ProcessScheduling
{
    /// <summary>
    /// Stellt die 5 möglichen Prozesszustände dar
    /// </summary>
    public enum ProcessState
    {
        New,
        Ready,
        Running,
        Waiting,
        Terminated
    }

    /// <summary>
    /// Datenkapsel für einen Prozess
    /// </summary>
    public class Process
    {
        #region Constants and Statics
        public const int MIN_PRIORITY = 0;
        public const int MAX_PRIORITY = 149;

        private const int IDLE_PID = 0;
        private const int IDLE_PRIORITY = MAX_PRIORITY + 1;

        private static int _nextID = IDLE_PID + 1;
        #endregion

        #region Private Fields
        private int _pid = 1;
        private int _priority;
        private ProcessState _state;
        private static Process _idleProcess;
        #endregion

        /// <summary>
        /// Öffentlicher Konstruktor zum Erzeugen
        /// eines Prozesses mit der gewünschten Priorität.
        /// Prozess-ID PID wird automatisch fortlaufend 
        /// zugewiesen.
        /// </summary>
        /// <param name="priority">Gewünschte Prozesspriorität</param>
        public Process(int priority) : this ()
        {
            PID = _nextID++;
            Priority = priority;
        }

        /// <summary>
        /// Privater Konstruktor, mit dem der IdleProcess 
        /// erzeugt werden kann.
        /// Default-Zustand eines frischen Prozesses ist
        /// immer "New".
        /// </summary>
        private Process()
        {
            State = ProcessState.New;
        }

        /// <summary>
        /// Es gibt im System genau eine Prozess-Instanz mit
        /// PID = 0 und der systemweit schlechtesten
        /// Priorität. Dieser IdleProcess wird bei
        /// dem ersten Zugriff auf dieses statische
        /// read-only Property erzeugt und später
        /// immer nur zurückgegeben.
        /// </summary>
        public static Process IdleProcess
        {
            get
            {
                if (_idleProcess == null)
                {
                    _idleProcess = new Process();
                    _idleProcess.PID = IDLE_PID;
                    _idleProcess.Priority = IDLE_PRIORITY;
                }
                return _idleProcess;
            }
        }

        /// <summary>
        /// PID ist read-only und kann nur
        /// privat exklusiv gesetzt werden.
        /// </summary>
        public int PID
        {
            get
            {
                return _pid;
            }

            private set
            {
                _pid = value;
            }
        }

        /// <summary>
        /// Die Prozesspriorität muß in einem
        /// definierten Wertebereich liegen.
        /// <see cref="MIN_PRIORITY"/> 
        /// <see cref="MAX_PRIORITY"/> 
        /// <see cref="IDLE_PRIORITY"/> 
        /// </summary>
        public int Priority
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        /// <summary>
        /// Property zum Setzen und Auslesen
        /// des Prozesszustands.
        /// </summary>
        public ProcessState State
        {
            get
            {
                return _state;
            }

            set
            {
                _state = value;
            }
        }
    }
}
