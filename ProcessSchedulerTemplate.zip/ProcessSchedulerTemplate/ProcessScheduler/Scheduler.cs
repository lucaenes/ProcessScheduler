﻿using System;

namespace ProcessScheduling
{

    /// <summary>
    /// Klasse zum Verwaltung des aktuell laufenden Prozesses.
    /// Alle anderen Prozesse befinden sich entweder in der 
    /// ReadyQueue oder in der WaitingQueue.
    /// </summary>
    public class Scheduler
    {

        /// <summary>
        /// Nur der Scheduler selbst darf den aktuell
        /// laufenden Prozess setzen.
        /// Das Auslesen des aktuell laufenden Prozesses
        /// hingegen ist öffentlich.
        /// </summary>
        public Process RunningProcess
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        /// <summary>
        /// Ein Prozesswechsel wird durchgeführt: Der
        /// aktuell laufende Prozess wird auf Ready
        /// zurückgesetzt (in die ReadyQueue eingereiht)
        /// und der vorderste Prozess aus der ReadyQueue
        /// wird zum RunningProcess. Gibt es keinen Ready-Prozess,
        /// kommt der IdleProcess zum Zug.
        /// </summary>
        public void ScheduleNextProcess()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Es kann nur ein laufender oder laufbereiter Prozess
        /// suspendiert werden, auch nicht der IdleProcess.
        /// </summary>
        /// <param name="p"></param>
        public void SuspendProcess(Process p)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Wenn der Prozess aus der WaitingQueue
        /// ausgekettet werden konnte, wird er in der
        /// ReadyQueue eingereiht.
        /// </summary>
        /// <param name="pid">Gesuchter Prozess muss diese PID haben.</param>
        public void ResumeProcess(int pid)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Ein Prozess kann aus jedem beliebigen Zustand heraus
        /// gekillt werden, es sei denn, es handelt sich um den
        /// IdleProcess.
        /// Wurde der laufende Prozess gekillt, muss sofort ein
        /// neuer Prozess auf die CPU zugewiesen werden.
        /// </summary>
        /// <param name="p">Zu killender Prozess</param>
        public void KillProcess(Process p)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Ein neuer Prozess wird dem Scheduler
        /// bekannt gemacht und sofort in die
        /// ReadyQueue eingereiht.
        /// </summary>
        /// <param name="p"></param>
        public void StartProcess(Process p)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Um das Verhungern des letztes Prozesses
        /// in der ReadyQueue zu verhindern, kann dessen
        /// Priorität um einen zu definierenden Wert
        /// verbessert werden.
        /// </summary>
        /// <param name="increment">
        /// Um welchen Wert soll die Priorität besser werden.</param>
        public void AgeLastProcess(int increment)
        {
            throw new NotImplementedException();
        }

    }
}
